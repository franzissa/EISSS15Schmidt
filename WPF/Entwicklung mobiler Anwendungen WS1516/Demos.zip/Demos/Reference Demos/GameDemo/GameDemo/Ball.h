//
//  Ball.h
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sprite.h"

typedef enum _BallBounceOrientation {
  kBallBounceOrientationHorizontal= 0,
  kBallBounceOrientationVertical
} BallBounceOrientation;

@interface Ball : Sprite

- (void)move;
- (void)bounce:(BallBounceOrientation)orientation;
- (void)resetDirections;

@end

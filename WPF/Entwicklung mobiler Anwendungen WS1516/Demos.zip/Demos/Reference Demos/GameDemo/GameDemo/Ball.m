//
//  Ball.m
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "Ball.h"

#define kDefaultDeltaX 1.0
#define kDefaultDeltaY 1.0

@implementation Ball {
  CGFloat _deltaX;
  CGFloat _deltaY;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
   self = [super initWithCoder:aDecoder];
   if (self) {
     [self resetDirections];
     
     self.layer.borderColor= [UIColor blackColor].CGColor;
     self.layer.borderWidth= 1.0;
     self.layer.cornerRadius= 8.0;
   }
   return self;
}

- (void)bounceWalls {
   UIView *outerView= self.superview;
   BOOL shouldBounce= !CGRectContainsRect(outerView.bounds, self.frame);
   
   if( !shouldBounce )
      return;
   
   if( CGRectGetMinX(self.frame) < CGRectGetMinX(outerView.bounds) || CGRectGetMaxX(self.frame) > CGRectGetMaxX(outerView.bounds) )
      _deltaX= -_deltaX;

   if( CGRectGetMinY(self.frame) < CGRectGetMinY(outerView.bounds) )
      _deltaY= -_deltaY;
   
}

- (void)bounce:(BallBounceOrientation)orientation {
  switch( orientation ) {
    case kBallBounceOrientationHorizontal:
      _deltaY= -_deltaY;
      break;
    case kBallBounceOrientationVertical:
      _deltaX= -_deltaX;
      break;
  }
}

- (void)move {
   [self bounceWalls];
   self.frame= CGRectOffset(self.frame, _deltaX, _deltaY);
}

- (void)resetDirections {
  _deltaX= kDefaultDeltaX;
  _deltaY= -kDefaultDeltaY;
}

@end

//
//  Paddle.h
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sprite.h"

@interface Paddle : Sprite

@end

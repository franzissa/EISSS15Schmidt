//
//  Sprite.m
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "Sprite.h"

@implementation Sprite

- (id)initWithFrame:(CGRect)frame
{
  self = [super initWithFrame:frame];
  if (self) {
    // Initialization code
  }
  return self;
}

- (SpriteCollisionType)collidesWith:(Sprite *)otherSprite {
  if( otherSprite.hidden )
    return kSpriteCollisionTypeNoCollision;
  
  if( fabsf(CGRectGetMaxX(self.frame) - CGRectGetMinX(otherSprite.frame)) < 1 || fabsf(CGRectGetMinX(self.frame) - CGRectGetMaxX(otherSprite.frame)) < 1 )
    if( CGRectGetMaxY(self.frame) >= CGRectGetMinY(otherSprite.frame) && CGRectGetMinY(self.frame) <= CGRectGetMaxY(otherSprite.frame) )
      return kSpriteCollisionTypeCollidesVertically;
  
  if( fabsf(CGRectGetMaxY(self.frame) - CGRectGetMinY(otherSprite.frame)) < 1 || fabsf(CGRectGetMinY(self.frame) - CGRectGetMaxY(otherSprite.frame)) < 1 )
    if( CGRectGetMaxX(self.frame) >= CGRectGetMinX(otherSprite.frame) && CGRectGetMinX(self.frame) <= CGRectGetMaxX(otherSprite.frame) )
      return kSpriteCollisionTypeCollidesHorizontally;
  
  return kSpriteCollisionTypeNoCollision;
}


@end

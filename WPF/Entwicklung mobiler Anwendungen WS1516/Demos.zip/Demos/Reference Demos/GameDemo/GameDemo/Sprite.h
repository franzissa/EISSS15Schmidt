//
//  Sprite.h
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum _SpriteCollisionType {
   kSpriteCollisionTypeNoCollision= 0,
   kSpriteCollisionTypeCollidesHorizontally,
   kSpriteCollisionTypeCollidesVertically,
} SpriteCollisionType;

@interface Sprite : UIView

- (SpriteCollisionType)collidesWith:(Sprite *)otherSprite;

@end

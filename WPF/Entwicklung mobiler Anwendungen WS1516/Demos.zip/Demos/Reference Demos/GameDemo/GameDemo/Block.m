//
//  Block.m
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "Block.h"

@implementation Block

- (id)initWithCoder:(NSCoder *)aDecoder {
  self= [super initWithCoder:aDecoder];
  
  if( self ) {
    uint32_t randColor= arc4random();
    self.backgroundColor= [UIColor colorWithRed:((randColor>>24)&0xFF)/256.0 green:((randColor>>16)&0xFF)/256.0 blue:(randColor&0xFF)/256.0 alpha:1.0];
    
    self.layer.borderColor= [UIColor blackColor].CGColor;
    self.layer.borderWidth= 0.5;
    self.layer.cornerRadius= 5.0;
  }
  
  return self;
}

@end

//
//  ViewController.m
//  GameDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import "BreakoutViewController.h"
#import "Block.h"
#import "Paddle.h"
#import "Ball.h"

@interface BreakoutViewController ()

@property (weak, nonatomic) IBOutlet UIView *blocksView;
@property (weak, nonatomic) IBOutlet Paddle *paddle;
@property (weak, nonatomic) IBOutlet Ball *ball;
@property (weak, nonatomic) IBOutlet UILabel *livesLabel;
@property (weak, nonatomic) IBOutlet UILabel *pointsLabel;

@property (assign, readonly, nonatomic) NSArray *blocks;

@property (assign, nonatomic) NSInteger lives;
@property (assign, nonatomic) NSInteger points;

@end

@implementation BreakoutViewController {
  CADisplayLink *_displayLink;
  BOOL _ballRunning;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
  self= [super initWithCoder:aDecoder];
  
  if( self ) {
    _displayLink= [CADisplayLink displayLinkWithTarget:self selector:@selector(updateDisplay:)];
    _displayLink.frameInterval= 1;
    _displayLink.paused= YES;
    [_displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
  }
  
  return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];

  self.lives= 3;
  self.points= 0;
}

- (void)viewWillAppear:(BOOL)animated {
  _displayLink.paused= NO;
}

- (void)viewWillDisappear:(BOOL)animated {
  _displayLink.paused= YES;
}

- (void)dealloc {
  [_displayLink invalidate];
}

- (NSArray *)blocks {
  return self.blocksView.subviews;
}

- (void)setLives:(NSInteger)lives {
  _lives= lives;
  self.livesLabel.text= [NSString stringWithFormat:@"Lives: %d", lives];
}

- (void)setPoints:(NSInteger)points {
  _points= points;
  self.pointsLabel.text= [NSString stringWithFormat:@"Points: %d", points];
}

#pragma mark - Game Logic

- (void)handleCollisions {
  // Ball collides with Paddle
  SpriteCollisionType paddleCollision= [self.ball collidesWith:self.paddle];
  
  if( paddleCollision == kSpriteCollisionTypeCollidesHorizontally )
    [self.ball bounce:kBallBounceOrientationHorizontal];
  else if( paddleCollision == kSpriteCollisionTypeCollidesVertically )
    [self.ball bounce:kBallBounceOrientationVertical];
  
  // Ball collides with blocks
  for( Block *block in self.blocks ) {
    SpriteCollisionType collisionType= [self.ball collidesWith:block];
    
    if( collisionType == kSpriteCollisionTypeNoCollision )
      continue;
    
    if( collisionType == kSpriteCollisionTypeCollidesHorizontally )
      [self.ball bounce:kBallBounceOrientationHorizontal];
    
    if( collisionType == kSpriteCollisionTypeCollidesVertically )
      [self.ball bounce:kBallBounceOrientationVertical];
    
    // Let the block disappear in a nice way...
    [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveLinear animations:^{
      block.alpha= 0.0;
      block.transform= CGAffineTransformMakeScale(0.7, 0.7);
    } completion:^(BOOL finished) {
      block.hidden= YES;
      self.points++;
    }];
    
    break;
  }
}

- (void)checkLifeLost {
  if( CGRectGetMaxY(self.ball.frame) > CGRectGetMaxY(self.view.bounds) ) {
    _ballRunning= NO;
    self.lives--;
    [self.ball resetDirections];
    
    // Game Over?
    if( self.lives == 0 ) {
      UIAlertView *alertView= [[UIAlertView alloc] initWithTitle:@"Game Over!" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
      [alertView show];
    }
  }
}

- (IBAction)panGestureAction:(UIPanGestureRecognizer *)sender {
  CGFloat xVelocity= [sender velocityInView:self.view].x;
  self.paddle.frame= CGRectOffset(self.paddle.frame, xVelocity/60, 0);
  
  // Reset to border if the paddles went off-screen
  if( CGRectGetMinX(self.paddle.frame) < 0 )
    self.paddle.frame= CGRectMake(0, self.paddle.frame.origin.y, self.paddle.frame.size.width, self.paddle.frame.size.height);
  else if( CGRectGetMaxX(self.paddle.frame) > CGRectGetWidth(self.view.bounds) )
    self.paddle.frame= CGRectMake(CGRectGetWidth(self.view.bounds) - CGRectGetWidth(self.paddle.frame), self.paddle.frame.origin.y, self.paddle.frame.size.width, self.paddle.frame.size.height);
}

- (IBAction)startGame:(id)sender {
  if( self.lives > 0 )
    _ballRunning= YES;
}

#pragma mark - DisplayLink Callback

- (void)updateDisplay:(CADisplayLink *)displayLink {
  if( !_ballRunning )
    self.ball.center= CGPointMake(self.paddle.center.x, self.paddle.center.y - CGRectGetHeight(self.paddle.frame)/2 - CGRectGetHeight(self.ball.frame)/2 - 1);
  else
    [self.ball move];

  //NSLog(@"ball %f/%f", self.ball.center.x, self.ball.center.y);
  
  [self checkLifeLost];
  [self handleCollisions];
}


@end

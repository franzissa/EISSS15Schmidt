//
//  Address.h
//  AddressbookDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Address : NSObject

@property (strong, nonatomic) NSString *forename;
@property (strong, nonatomic) NSString *surname;
@property (strong, nonatomic) NSString *position;

- initWithForename:(NSString*)forename surname:(NSString*)surname position:(NSString*)position;

- (NSDictionary*)writableRepresentation;

+ (Address*)addressFromDictionary:(NSDictionary*)dictionaryRepresentation;


@end

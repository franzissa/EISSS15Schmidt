//
//  Address.m
//  AddressbookDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "Address.h"

@implementation Address

- initWithForename:(NSString*)forename surname:(NSString*)surname position:(NSString*)position {
  self= [super init];
  
  if( self ) {
    self.forename= forename;
    self.surname= surname;
    self.position= position;
  }
  
  return self;
}

- (NSDictionary*)writableRepresentation {
  NSMutableDictionary *writableRepresentation= [NSMutableDictionary dictionaryWithCapacity:4];
  
  [writableRepresentation setValue:self.forename forKey:@"Forename"];
  [writableRepresentation setValue:self.surname forKey:@"Surname"];
  [writableRepresentation setValue:self.position forKey:@"Position"];
  
  return writableRepresentation;
}

+ (Address*)addressFromDictionary:(NSDictionary*)dictionaryRepresentation {
  return [[Address alloc] initWithForename:[dictionaryRepresentation valueForKey:@"Forename"] surname:[dictionaryRepresentation valueForKey:@"Surname"] position:[dictionaryRepresentation valueForKey:@"Position"]];
}

@end

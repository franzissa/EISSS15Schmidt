//
//  AddressViewController.m
//  AddressbookDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "AddressViewController.h"
#import "Address.h"
#import "AddressDetailViewController.h"


@implementation AddressViewController {
  NSArray *_addresses;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
  self= [super initWithCoder:aDecoder];
  
  if( self ) {
    // Create some bogus address data
    [self loadAdresses];

    // Initialize address array
    if( !_addresses  ) {
      _addresses= @[
      [[Address alloc] initWithForename:@"Alfred" surname:@"Becker" position:@"Bäckermeister"],
      [[Address alloc] initWithForename:@"Angela" surname:@"Bennet" position:@"Systems Analyst"],
      [[Address alloc] initWithForename:@"Daniel" surname:@"Klein" position:@"Freelance Superdude"],
      [[Address alloc] initWithForename:@"Werner" surname:@"Müller" position:@"Hausmeister"],
      [[Address alloc] initWithForename:@"Ina" surname:@"Meier" position:@"Human Resources Manager"],
      [[Address alloc] initWithForename:@"Dade" surname:@"Murphy" position:@"Zero Cool"],
      [[Address alloc] initWithForename:@"Herta" surname:@"Segelknecht" position:@"Rentnerin"]
      ];
    }
  }
  
  return self;
}

- (void)viewWillAppear:(BOOL)animated {
  if( self.tableView.indexPathForSelectedRow ) {
    [self.tableView reloadData];
    [self storeAddresses];
  }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_addresses count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString *cellIdentifier = @"AddressCell";
  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];
  
  Address *address= _addresses[indexPath.row];
  cell.textLabel.text= [NSString stringWithFormat:@"%@ %@", address.forename, address.surname];
  cell.detailTextLabel.text= address.position;
  
  return cell;
}

#pragma mark - Segue Handling

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
  if( [segue.identifier isEqualToString:@"Show Address Details"] ) {
    AddressDetailViewController *addressDetailViewController= segue.destinationViewController;
    addressDetailViewController.address= _addresses[self.tableView.indexPathForSelectedRow.row];
  }
}

#pragma mark - Load & Storing of the addressbook-array

- (NSURL*)addressPath {
  NSFileManager *sharedFileManager= [NSFileManager defaultManager];
  NSArray *paths= [sharedFileManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask];
  NSURL *documentsPath= paths[0];
  
  NSURL *filePath= [documentsPath URLByAppendingPathComponent:@"Address.plist"];

  return filePath;
}

- (NSArray*)writableRepresentation {
  NSMutableArray *writableArray= [NSMutableArray arrayWithCapacity:_addresses.count];
  
  for( Address *address in _addresses )
    [writableArray addObject:[address writableRepresentation]];
  
  return writableArray;
}

- (NSArray*)addressesFromDictionaryArray:(NSArray*)dictionaryArray {
  NSMutableArray *addresses= [NSMutableArray arrayWithCapacity:dictionaryArray.count];
  
  for( NSDictionary *dict in dictionaryArray )
    [addresses addObject:[Address addressFromDictionary:dict]];
  
  return addresses;
}

- (void)loadAdresses {
  NSURL *file= [self addressPath];
  
  NSArray *dictionaryResult= [NSArray arrayWithContentsOfURL:file];
  
  if( !dictionaryResult ) {
    NSLog(@"Could not load addresses!");
    return;
  }
  
  _addresses= [self addressesFromDictionaryArray:dictionaryResult];
  NSLog(@"Addresses loaded");
}

- (void)storeAddresses {
  NSURL *file= [self addressPath];
  NSArray *writableArray= [self writableRepresentation];
  
  // Write addresses file
  BOOL success= [writableArray writeToURL:file atomically:YES];
  NSLog(@"%@", success ? @"Addresses written" : @"Error writing addresses");
}

@end

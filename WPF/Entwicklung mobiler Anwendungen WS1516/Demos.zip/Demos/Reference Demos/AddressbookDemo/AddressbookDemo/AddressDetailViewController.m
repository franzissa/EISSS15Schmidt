//
//  AddressDetailViewController.m
//  AddressbookDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "AddressDetailViewController.h"

@interface AddressDetailViewController ()

@property (weak, nonatomic) IBOutlet UITextField *forenameTextField;
@property (weak, nonatomic) IBOutlet UITextField *surnameTextField;
@property (weak, nonatomic) IBOutlet UITextField *positionTextField;

@end

@implementation AddressDetailViewController

- (void)viewDidLoad {
  [super viewDidLoad];
  self.forenameTextField.delegate= self;
  self.surnameTextField.delegate= self;
  self.positionTextField.delegate= self;
}

- (void)viewWillAppear:(BOOL)animated {
  self.forenameTextField.text= self.address.forename;
  self.surnameTextField.text= self.address.surname;
  self.positionTextField.text= self.address.position;
}

- (void)viewWillDisappear:(BOOL)animated {
  // Update address
  self.address.forename= self.forenameTextField.text;
  self.address.surname= self.surnameTextField.text;
  self.address.position= self.positionTextField.text;
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[textField resignFirstResponder];
	return YES;
}


@end

//
//  AddressDetailViewController.h
//  AddressbookDemo
//
//  Created by Daniel Klein on 02.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Address.h"


@interface AddressDetailViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) Address *address;

@end

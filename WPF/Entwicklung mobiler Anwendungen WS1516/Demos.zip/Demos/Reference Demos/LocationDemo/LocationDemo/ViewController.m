//
//  ViewController.m
//  LocationDemo
//
//  Created by Daniel Klein on 09.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()
@end

@implementation ViewController {
  CLLocationManager *_locationManager;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
  self= [super initWithCoder:aDecoder];
  
  if( self ) {
    _locationManager= [[CLLocationManager alloc] init];
    _locationManager.delegate= self;
    
    NSLog(@"Location services enabled: %d", [CLLocationManager locationServicesEnabled]);
    NSLog(@"Region monitoring available: %d", [CLLocationManager regionMonitoringAvailable]);
    NSLog(@"Significant location change monitoring available: %d", [CLLocationManager significantLocationChangeMonitoringAvailable]);
    NSLog(@"Heading available: %d", [CLLocationManager headingAvailable]);
    NSLog(@"Authorization state: %d", [CLLocationManager authorizationStatus]);
    
    [_locationManager startUpdatingLocation];
  }
  
  return self;
}

- (void)dealloc {
  [_locationManager stopUpdatingLocation];
}

#pragma mark - CLLocationManagerDelegate Callbacks

- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
  NSLog(@"Authorization state changed to: %d", status);
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
  NSLog(@"LocationManager did fail with error: %@", error);
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
  NSLog(@"New locations received: %@", locations);
}

@end

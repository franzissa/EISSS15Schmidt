//
//  AppDelegate.h
//  LocationDemo
//
//  Created by Daniel Klein on 09.01.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

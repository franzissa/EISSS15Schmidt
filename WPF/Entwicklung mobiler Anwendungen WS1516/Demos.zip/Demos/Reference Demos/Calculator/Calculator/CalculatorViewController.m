//
//  ViewController.m
//  Calculator
//
//  Created by Daniel Klein on 03.07.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "CalculatorViewController.h"
#import "Calculator.h"

@interface CalculatorViewController ()

@property (weak, nonatomic) IBOutlet UILabel *displayLabel;
@property (weak, nonatomic) IBOutlet UIButton *decimalSeparatorButton;

@property (strong, nonatomic) Calculator *calculator;

@end

@implementation CalculatorViewController

- (id)initWithCoder:(NSCoder *)aDecoder {
  self= [super initWithCoder:aDecoder];
  
  if( self ) {
    self.calculator= [Calculator new];
  }
  
  return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
  // Manually set LCD font (can't do that with Interface Builder)
  self.displayLabel.font= [UIFont fontWithName:@"DB LCD Temp" size:26];
  
  // Localize decimal separator button
  [self.decimalSeparatorButton setTitle:[[NSLocale currentLocale] objectForKey:NSLocaleDecimalSeparator] forState:UIControlStateNormal];
  
  [self.calculator addObserver:self forKeyPath:@"display" options:NSKeyValueObservingOptionInitial|NSKeyValueObservingOptionNew context:nil];
}

- (void)dealloc {
  [self.calculator removeObserver:self forKeyPath:@"display"];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
  if( [keyPath isEqualToString:@"display"] )
    self.displayLabel.text= change[NSKeyValueChangeNewKey];
}

- (IBAction)numberButtonTouched:(UIButton *)sender {
  [self.calculator addNumber:sender.currentTitle.integerValue];
}

- (IBAction)decimalSeparatorButtonTouched:(id)sender {
  [self.calculator addDecimalSeparator];
}

- (IBAction)equalsButtonTouched:(id)sender {
  [self.calculator calculate];
}

- (IBAction)plusButtonTouched:(id)sender {
  self.calculator.currentOperator= CalculatorOperatorAdd;
}

- (IBAction)minusButtonTouched:(id)sender {
  self.calculator.currentOperator= CalculatorOperatorSubtract;
}

- (IBAction)multiplyButtonTouched:(id)sender {
  self.calculator.currentOperator= CalculatorOperatorMultiply;
}

- (IBAction)divideButtonTouched:(id)sender {
  self.calculator.currentOperator= CalculatorOperatorDivide;
}

- (IBAction)negateButtonTouched:(id)sender {
  [self.calculator negate];
}

- (IBAction)allClearButtonTouched:(id)sender {
  [self.calculator clear];
}

@end

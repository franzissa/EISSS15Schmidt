//
//  Calculator.h
//  Calculator
//
//  Created by Daniel Klein on 03.07.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum _CalculatorOperators : NSUInteger {
  CalculatorOperatorAdd = 0,
  CalculatorOperatorSubtract,
  CalculatorOperatorMultiply,
  CalculatorOperatorDivide
} CalculatorOperator;

@interface Calculator : NSObject

@property (strong, nonatomic) NSString *display;
@property (assign, nonatomic) CalculatorOperator currentOperator;

- (void)addNumber:(NSUInteger)number;
- (void)addDecimalSeparator;

- (void)clear;
- (void)negate;
- (void)calculate;

@end

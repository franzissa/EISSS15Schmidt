//
//  Calculator.m
//  Calculator
//
//  Created by Daniel Klein on 03.07.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import "Calculator.h"

@interface Calculator ()

@property (strong, nonatomic) NSDecimalNumber *rememberedValue;
@property (assign, nonatomic) BOOL clearOnNextEntry;
@property (assign, nonatomic) BOOL resetOnNextEntry;
@property (strong, nonatomic) NSString *localizedDecimalSeparator;

@end

@implementation Calculator

- (id)init {
  self= [super init];
  
  if( self ) {
    self.localizedDecimalSeparator= [[NSLocale currentLocale] objectForKey:NSLocaleDecimalSeparator];
    [self clear];
  }
  
  return self;
}

- (void)addNumber:(NSUInteger)number {
  // Don't add more zeros to a single zero
  if( [self.display isEqualToString:@"0"] && number == 0 )
    return;
  
  if( self.resetOnNextEntry ) {
    self.rememberedValue= nil;
    self.resetOnNextEntry= NO;
  }
  
  if( self.clearOnNextEntry ) {
    self.display= @"";
    self.clearOnNextEntry= NO;
  }
  
  self.display= [self.display stringByAppendingString:@(number).stringValue];
}

- (void)addDecimalSeparator {
  if( self.clearOnNextEntry ) {
    self.display= @"0";
    self.clearOnNextEntry= NO;
  }
  
  NSRange decimalPointRange= [self.display rangeOfString:self.localizedDecimalSeparator];
  BOOL decimalPointPresent= decimalPointRange.length != 0;
  
  if( !decimalPointPresent )
    self.display= [self.display stringByAppendingString:self.localizedDecimalSeparator];
}

- (void)clear {
  self.display= @"0";
  self.clearOnNextEntry= YES;
  self.rememberedValue= nil;
}

- (void)negate {
  // Don't negate 0
  if( [self.display isEqualToString:@"0"] )
    return;
  
  if( [self.display hasPrefix:@"-"] )
    self.display= [self.display substringFromIndex:1];
  else
    self.display= [@"-" stringByAppendingString:self.display];
}

- (void)calculate {
  // We can not calculate if we don't have a second operand
  if( !self.rememberedValue )
    return;
  
  NSDecimalNumber *leftOperand;
  NSDecimalNumber *rightOperand;
  NSDecimalNumber *result;
  
  // If clearOnNextEntry is set, we do have a repeated calculation (pressing equals repeatedly after a calculation), for which we have to swivel the operands.
  if( self.clearOnNextEntry ) {
    leftOperand= [NSDecimalNumber decimalNumberWithString:self.display];
    rightOperand= self.rememberedValue;
  }
  else {
    leftOperand= self.rememberedValue;
    rightOperand= [NSDecimalNumber decimalNumberWithString:self.display];
  }
  
  switch( self.currentOperator ) {
    case CalculatorOperatorAdd:
      result= [leftOperand decimalNumberByAdding:rightOperand];
      break;
    case CalculatorOperatorSubtract:
      result= [leftOperand decimalNumberBySubtracting:rightOperand];
      break;
    case CalculatorOperatorMultiply:
      result= [leftOperand decimalNumberByMultiplyingBy:rightOperand];
      break;
    case CalculatorOperatorDivide:
      result= [leftOperand decimalNumberByDividingBy:rightOperand];
      break;
  }
  
  self.rememberedValue= rightOperand;
  self.display= result.stringValue;
  self.clearOnNextEntry= YES;
  self.resetOnNextEntry= YES;
}

- (void)setCurrentOperator:(CalculatorOperator)operator {
  // Don't reset if we continue with the last result
  if( self.resetOnNextEntry ) {
    self.rememberedValue= nil;
    self.resetOnNextEntry= NO;
  }
  
  _currentOperator= operator;
  
  if( self.rememberedValue )
    [self calculate];
  
  self.rememberedValue= [NSDecimalNumber decimalNumberWithString:self.display];
  self.clearOnNextEntry= YES;
  self.resetOnNextEntry= NO;
}

@end

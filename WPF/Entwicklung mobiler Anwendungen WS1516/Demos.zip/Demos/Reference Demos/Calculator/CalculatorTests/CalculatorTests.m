//
//  CalculatorTests.m
//  CalculatorTests
//
//  Created by Daniel Klein on 03.07.13.
//  Copyright (c) 2013 Daniel Klein. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface CalculatorTests : XCTestCase

@end

@implementation CalculatorTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end

//
//  MyTableViewController.h
//  Calculator
//
//  Created by Daniel Klein on 06.01.16.
//  Copyright © 2016 Daniel Klein. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewController : UITableViewController

@end

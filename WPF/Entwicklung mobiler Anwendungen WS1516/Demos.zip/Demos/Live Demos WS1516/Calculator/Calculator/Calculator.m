//
//  Calculator.m
//  Calculator
//
//  Created by Daniel Klein on 06.01.16.
//  Copyright © 2016 Daniel Klein. All rights reserved.
//

#import "Calculator.h"

@implementation Calculator

- (instancetype)init {
	self = [super init];
	
	if( self ) {
		self.display = @"0";
	}
	
	return self;
}

@end

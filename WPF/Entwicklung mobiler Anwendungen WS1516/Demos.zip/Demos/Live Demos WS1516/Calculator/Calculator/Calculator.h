//
//  Calculator.h
//  Calculator
//
//  Created by Daniel Klein on 06.01.16.
//  Copyright © 2016 Daniel Klein. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum : NSUInteger {
	CalculatorOperatorAdd = 0,
	CalculatorOperatorSubtract,
	CalculatorOperatorMultiply,
	CalculatorOperatorDivide
} CalculatorOperator;

@interface Calculator : NSObject

@property (strong, nonatomic) NSString *display;
@property (assign, nonatomic) CalculatorOperator currentOperator;

- (void)addNumber:(NSUInteger)number;
- (void)addDecimalOperator;

- (void)clear;
- (void)negate;
- (void)calculate;

@end

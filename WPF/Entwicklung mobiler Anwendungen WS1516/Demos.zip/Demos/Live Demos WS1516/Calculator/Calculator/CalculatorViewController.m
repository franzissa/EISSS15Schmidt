//
//  ViewController.m
//  Calculator
//
//  Created by Daniel Klein on 06.01.16.
//  Copyright © 2016 Daniel Klein. All rights reserved.
//

#import "CalculatorViewController.h"
#import "Calculator.h"

@interface CalculatorViewController ()

@property (strong, nonatomic) IBOutlet UILabel *outputLabel;
@property (strong, nonatomic) Calculator *calculator;

@end

@implementation CalculatorViewController

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
	self = [super initWithCoder:aDecoder];
	
	if( self ) {
		self.calculator = [[Calculator alloc] init];
	}
	
	return self;
}


- (void)viewDidLoad {
	[super viewDidLoad];
	self.outputLabel.font = [UIFont fontWithName:@"DB LCD Temp" size:26];
	
	[self.calculator addObserver:self forKeyPath:@"display" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionInitial context:nil];
}

- (void)dealloc {
	[self.calculator removeObserver:self forKeyPath:@"display"];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context {
	if( object == self.calculator && [keyPath isEqualToString:@"display"] ) {
		self.outputLabel.text = self.calculator.display;
	}
}

- (IBAction)addButtonTouched:(UIButton *)sender {
}
- (IBAction)substractButtonTouched:(UIButton *)sender {
}
- (IBAction)multiplyButtonTouched:(UIButton *)sender {
}
- (IBAction)divideButtonTouched:(UIButton *)sender {
}
- (IBAction)negateButtonTouched:(UIButton *)sender {
}
- (IBAction)clearButtonTouched:(UIButton *)sender {
}
- (IBAction)decimalSeparatorButtonTouched:(UIButton *)sender {
}
- (IBAction)equalsButtonToched:(UIButton *)sender {
}
- (IBAction)numberButtonTouched:(UIButton *)sender {
	
}

- (IBAction)exitToCalculator:(UIStoryboardSegue*)segue {
	// Intentionally left empty
}

@end

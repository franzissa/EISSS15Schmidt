//
//  MyTableViewController.m
//  Calculator
//
//  Created by Daniel Klein on 06.01.16.
//  Copyright © 2016 Daniel Klein. All rights reserved.
//

#import "MyTableViewController.h"

@interface MyTableViewController ()

@property (strong, nonatomic) NSArray *data;

@end

@implementation MyTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
	self.data = @[@"Maria", @"Peter", @"Kristia", @"Helga", @"Leonie", @"Herbert", @"Magda", @"Paul", @"Rufus", @"Andreas", @"Rudolf", @"Norbert"];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.data.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	NSString *name = self.data[indexPath.row];
	
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Werbung anzeigen" forIndexPath:indexPath];
    
	cell.textLabel.text = name;
	
    return cell;
}

@end

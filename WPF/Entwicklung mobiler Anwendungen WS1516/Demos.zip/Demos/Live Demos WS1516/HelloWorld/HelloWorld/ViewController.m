//
//  ViewController.m
//  HelloWorld
//
//  Created by Daniel Klein on 04.01.16.
//  Copyright © 2016 Daniel Klein. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UILabel *greetingLabel;

@end

@implementation ViewController
- (IBAction)greetingsButtonTouched:(UIButton *)sender {
	NSString *name = self.nameTextField.text;
	NSString *greeting = [NSString stringWithFormat:@"Hello %@", name];
	self.greetingLabel.text = greeting;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
	[self.nameTextField endEditing:YES];
	return NO;
}
- (IBAction)labelTapped:(id)sender {
	NSLog(@"Tapped!");
}
- (IBAction)labelSwiped:(id)sender {
	NSLog(@"Swiped!");
}

@end





